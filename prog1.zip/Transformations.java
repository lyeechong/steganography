/*

CS314H Programming Assignment 1 - Java image processing

 *  Student information for assignment:
 *
 *  On my honor, Lyee Chong, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *  
 *  Programming Assignment #1 - Image Manipulation
 *  Name: Lyee Chong
 *  UTEID: lsc568
 *  email address: lyeechong@gmail.com
 *  September 2, 2011
 *  Professor: Calvin Lin
 *  Course: C S 314H
 *  Unique course number: 52318
 * 
 */

import java.util.ArrayList;

//invert the image using unary bitwise negation
class InvertEffect extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;

        //go through all pixels in the matrix
        for (int r = 0; r < height; r++)
        {
            for (int c = 0; c < width; c++)
            {
                //invert the pixel using unary bitwise negation
                pixels[r][c] = ~pixels[r][c];
            }
        }
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "Invert image";
    }
}

//remove red in all the pixels by setting the red value to 0
class NoRed extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;
        //go through all pixels in the matrix
        for (int r = 0; r < height; r++)
        {
            for (int c = 0; c < width; c++)
            {
                //create a new pixel and replace the curent one at that spot with one with the red value set to 0
                pixels[r][c] = makePixel(0, getGreen(pixels[r][c]), getBlue(pixels[r][c]));
            }
        }
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "No red";
    }
}

//remove green in all the pixels by setting the green value to 0
class NoGreen extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;
        //go through all pixels in the matrix
        for (int r = 0; r < height; r++)
        {
            for (int c = 0; c < width; c++)
            {
                //create a new pixel and replace the curent one at that spot with one with the green value set to 0
                pixels[r][c] = makePixel(getRed(pixels[r][c]), 0, getBlue(pixels[r][c]));
            }
        }
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "No green";
    }
}

//remove blue in all the pixels by setting the blue value to 0
class NoBlue extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;
        //go through all pixels in the matrix
        for (int r = 0; r < height; r++)
        {
            for (int c = 0; c < width; c++)
            {
                //create a new pixel and replace the curent one at that spot with one with the blue value set to 0
                pixels[r][c] = makePixel(getRed(pixels[r][c]), getGreen(pixels[r][c]), 0);
            }
        }
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "No blue";
    }
}

//leave only red in all the pixels by setting the green and blue values to 0
class RedOnlyEffect extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;
        //go through all pixels in the matrix
        for (int r = 0; r < height; r++)
        {
            for (int c = 0; c < width; c++)
            {
                //make a new pixel with the red value left alone and setting the other two to 0
                pixels[r][c] = makePixel(getRed(pixels[r][c]), 0, 0);
            }
        }
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "Red only effect";
    }
}

//leave only green in all the pixels by setting the blue and red values to 0
class GreenOnlyEffect extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;
        //go through all pixels in the matrix
        for (int r = 0; r < height; r++)
        {
            for (int c = 0; c < width; c++)
            {
                //make a new pixel with the green value left alone and setting the other two to 0
                pixels[r][c] = makePixel(0, getGreen(pixels[r][c]), 0);
            }
        }
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "Green only effect";
    }
}

//leave only blue in all the pixels by setting the green and red values to 0
class BlueOnlyEffect extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;
        //go through all pixels in the matrix
        for (int r = 0; r < height; r++)
        {
            for (int c = 0; c < width; c++)
            {
                //make a new pixel with the blue value left alone and setting the other two to 0
                pixels[r][c] = makePixel(0, 0, getBlue(pixels[r][c]));
            }
        }
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "Blue only effect";
    }
}

//makes the image greyscale by averaging out the intensity of the red, blue, and green values in each pixel
class BlackAndWhite extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;
        //go through all pixels in the matrix
        for (int r = 0; r < height; r++)
        {
            for (int c = 0; c < width; c++)
            {
                //find the average value of all the three colors (red, green, blue) and set the result as the value for all three in the new pixel
                int greyVal = (getBlue(pixels[r][c]) + getRed(pixels[r][c]) + getGreen(pixels[r][c])) / 3;
                pixels[r][c] = makePixel(greyVal, greyVal, greyVal);
            }
        }
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "Black and white";
    }
}

//reflects the image from left to right
class VerticalReflect extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;

        for (int r = 0; r < height; r++)
        {
            for (int c = 0; c < width / 2; c++)
            {
                //swap the pixel on the left with the corresponding one on the right
                int tempPix = pixels[r][width - 1 - c];
                pixels[ r][width - 1 - c] = pixels[r][c];
                pixels[r][c] = tempPix;
            }
        }
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "Vertical reflect across center";
    }
}

//reflect the image from bottom to top
class HorizontalReflect extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;
        for (int r = 0; r < height / 2; r++)
        {
            for (int c = 0; c < width; c++)
            {
                //swap the pixel on the bottom with the corresponding one on the top
                int tempPix = pixels[height - 1 - r][c];
                pixels[ height - 1 - r][c] = pixels[r][c];
                pixels[r][c] = tempPix;
            }
        }
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "Horizontal reflect across center";
    }
}

//enlarge the image by four times by replicating one pixel four times in the new image
class Grow extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;
        int[][] newPixelMap = new int[height * 2][width * 2];
        //go through matrix, skipping every other spot
        for (int r = 0; r < height * 2; r += 2)
        {
            for (int c = 0; c < width * 2; c += 2)
            {
                //get the value at the original spot
                //then set the four nearby pixels in the new image to that value
                int val = pixels[r / 2][c / 2];
                newPixelMap[r][c] = val;
                newPixelMap[r + 1][c] = val;
                newPixelMap[r][c + 1] = val;
                newPixelMap[r + 1][c + 1] = val;
            }
        }
        return newPixelMap; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "Grow image four times larger";
    }
}

//Shrink image to a forth size by finding the average
class Shrink extends ImageEffect
{

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        int height = pixels.length;
        int width = pixels[0].length;
        //find the new height of the smaller image by diving the original height by two, and if it is of size zero, make it size 1
        int newHeight = (height / 2) > 0 ? (height / 2) : 1;
        //find the new width  of the smaller image by diving the original width by two, and if it is of size zero, make it size 1
        int newWidth = (width / 2) > 0 ? (width / 2) : 1;
        int[][] newPixelMap = new int[newHeight][newWidth];

        //if the image is smaller than or equal to a 2x2 pixel image
        if (height <= 2 && width <= 2)
        {
            int red = 0;
            int green = 0;
            int blue = 0;
            int pixelCounter = 0; //counts how many pixels are in the image
            for (int r = 0; r < height; r++)
            {
                for (int c = 0; c < width; c++)
                {
                    red += getRed(pixels[r][c]);
                    green += getGreen(pixels[r][c]);
                    blue += getBlue(pixels[r][c]);
                    pixelCounter++;
                }
            }
            return new int[][]
                    {
                        {
                            //make a new image of one pixel, consisting of the average values of the colors
                            makePixel(red / pixelCounter, green / pixelCounter, blue / pixelCounter)
                        }
                    };
        }

        //if the image is larger than a 2x2
        //go through all pixels and average out the value of four pixels to form one new one
        for (int r = 0; r < ((height / 2) > 0 ? (height / 2) : 1); r++)
        {
            for (int c = 0; c < ((width / 2) > 0 ? (width / 2) : 1); c++)
            {
                //average the red hue
                int red =
                        (getRed(pixels[r * 2][c * 2])
                        + getRed(pixels[r * 2 + 1][c * 2])
                        + getRed(pixels[r * 2][c * 2 + 1])
                        + getRed(pixels[r * 2 + 1][c * 2 + 1])) / 4;
                //average the green hue
                int green =
                        (getGreen(pixels[r * 2][c * 2])
                        + getGreen(pixels[r * 2 + 1][c * 2])
                        + getGreen(pixels[r * 2][c * 2 + 1])
                        + getGreen(pixels[r * 2 + 1][c * 2 + 1])) / 4;
                //average the blue hue
                int blue =
                        (getBlue(pixels[r * 2][c * 2])
                        + getBlue(pixels[r * 2 + 1][c * 2])
                        + getBlue(pixels[r * 2][c * 2 + 1])
                        + getBlue(pixels[r * 2 + 1][c * 2 + 1])) / 4;
                newPixelMap[r][c] = makePixel(red, green, blue); //make a new pixel based on the average hues


            }
        }
        pixels = newPixelMap;
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "Shrink image to a forth size";
    }
}
//if a color is larger than a threshold, increase it to the max intensity, otherwise make its intensity zero
class Threshold extends ImageEffect
{

    public Threshold()
    {
        super();
        params = new ArrayList<ImageEffectParam>();
        params.add(new ImageEffectIntParam("Threshold value",
                "Threshold value of color",
                10, 0, 1000));
    }

    public int[][] apply(int[][] pixels, ArrayList<ImageEffectParam> params)
    {
        ImageEffectIntParam intParam = (ImageEffectIntParam) params.get(0);
        int thresholdInput = intParam.getValue(); //get the value of the threshold argument

        int height = pixels.length;
        int width = pixels[0].length;
        //go through all pixels in the matrix
        for (int r = 0; r < height; r++)
        {
            for (int c = 0; c < width; c++)
            {
                //if the value of the color is bigger than the threshold, then make it 255, otherwise
                //make the value equal to zero
                pixels[r][c] = makePixel(getRed(pixels[r][c]) >= thresholdInput ? 255 : 0,
                        getGreen(pixels[r][c]) >= thresholdInput ? 255 : 0,
                        getBlue(pixels[r][c]) >= thresholdInput ? 255 : 0);
            }
        }
        return pixels; //returns the new matrix of pixels, with the added effects
    }

    public String getDescription()
    {
        return "Reduce colors by threshold";
    }
}